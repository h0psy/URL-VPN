@echo off
echo <?xml version="1.0" encoding="UTF-8"?>
<project version="4">
  <component name="DeviceStreaming">
    <option name="deviceSelectionList">
      <list>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="Sony" />
          <option name="codename" value="A402SO" />
          <option name="id" value="A402SO" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Sony" />
          <option name="name" value="Xperia 10 VI" />
          <option name="screenDensity" value="454" />
          <option name="screenX" value="1090" />
          <option name="screenY" value="2530" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="27" />
          <option name="brand" value="DOCOMO" />
          <option name="codename" value="F01L" />
          <option name="id" value="F01L" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="FUJITSU" />
          <option name="name" value="F-10L" />
          <option name="screenDensity" value="360" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1280" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="Infinix" />
          <option name="codename" value="Infinix-X6525" />
          <option name="id" value="Infinix-X6525" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="INFINIX MOBILITY LIMITED" />
          <option name="name" value="Infinix SMART 8" />
          <option name="screenDensity" value="320" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1612" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="OnePlus" />
          <option name="codename" value="OP535DL1" />
          <option name="id" value="OP535DL1" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="OnePlus" />
          <option name="name" value="Nord CE 2 Lite 5G" />
          <option name="screenDensity" value="401" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2412" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="OnePlus" />
          <option name="codename" value="OP5552L1" />
          <option name="id" value="OP5552L1" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="OnePlus" />
          <option name="name" value="10T 5G" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2412" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="OPPO" />
          <option name="codename" value="OP573DL1" />
          <option name="id" value="OP573DL1" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="OPPO" />
          <option name="name" value="A79 5G" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="OPPO" />
          <option name="codename" value="OP5759L1" />
          <option name="id" value="OP5759L1" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="OPPO" />
          <option name="name" value="A38" />
          <option name="screenDensity" value="320" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1612" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="realme" />
          <option name="codename" value="RE58C2" />
          <option name="id" value="RE58C2" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="realme" />
          <option name="name" value="C53" />
          <option name="screenDensity" value="320" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="30" />
          <option name="brand" value="realme" />
          <option name="codename" value="RMX3231" />
          <option name="id" value="RMX3231" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="realme" />
          <option name="name" value="RMX3231" />
          <option name="screenDensity" value="320" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="SC-51C" />
          <option name="id" value="SC-51C" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S22" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="SC-51E" />
          <option name="id" value="SC-51E" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S24" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="SC-53C" />
          <option name="id" value="SC-53C" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A53 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="SCG13" />
          <option name="id" value="SCG13" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S22" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="28" />
          <option name="brand" value="DOCOMO" />
          <option name="codename" value="SH-01L" />
          <option name="id" value="SH-01L" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="SHARP" />
          <option name="name" value="AQUOS sense2 SH-01L" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2160" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="31" />
          <option name="brand" value="TECNO" />
          <option name="codename" value="TECNO-BF6" />
          <option name="id" value="TECNO-BF6" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="TECNO" />
          <option name="name" value="POP 7" />
          <option name="screenDensity" value="320" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1612" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="31" />
          <option name="brand" value="TECNO" />
          <option name="codename" value="TECNO-BF7" />
          <option name="id" value="TECNO-BF7" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="TECNO" />
          <option name="name" value="TECNO" />
          <option name="screenDensity" value="320" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1612" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="TECNO" />
          <option name="codename" value="TECNO-BG6" />
          <option name="id" value="TECNO-BG6" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="TECNO MOBILE LIMITED" />
          <option name="name" value="SPARK Go 2024" />
          <option name="screenDensity" value="320" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1612" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="31" />
          <option name="brand" value="TECNO" />
          <option name="codename" value="TECNO-KI5k" />
          <option name="id" value="TECNO-KI5k" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="TECNO" />
          <option name="name" value="SPARK 10C" />
          <option name="screenDensity" value="320" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1612" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a03su" />
          <option name="id" value="a03su" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A03s" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a03sutfn" />
          <option name="id" value="a03sutfn" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A03s" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a04s" />
          <option name="id" value="a04s" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A04s" />
          <option name="screenDensity" value="300" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a05s" />
          <option name="id" value="a05s" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A05s" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a06" />
          <option name="id" value="a06" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A06" />
          <option name="screenDensity" value="300" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a13" />
          <option name="id" value="a13" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A13" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2408" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a13x" />
          <option name="id" value="a13x" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A13 5G" />
          <option name="screenDensity" value="300" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a14m" />
          <option name="id" value="a14m" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A14" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2408" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a14xmsq" />
          <option name="id" value="a14xmsq" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A14 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2408" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a14xmtfn" />
          <option name="id" value="a14xmtfn" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A14 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2408" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a15" />
          <option name="id" value="a15" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A15" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a15x" />
          <option name="id" value="a15x" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A15 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a15x" />
          <option name="id" value="a15x" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A15 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a15xtfn" />
          <option name="id" value="a15xtfn" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A15 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a16" />
          <option name="id" value="a16" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A16" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a16x" />
          <option name="id" value="a16x" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A16 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a16x" />
          <option name="id" value="a16x" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A16 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a16xeea" />
          <option name="id" value="a16xeea" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A16 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="31" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a21" />
          <option name="id" value="a21" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A21" />
          <option name="screenDensity" value="300" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a23xq" />
          <option name="id" value="a23xq" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A23 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2408" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a26x" />
          <option name="id" value="a26x" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A26 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="31" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a31" />
          <option name="id" value="a31" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A31" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a32" />
          <option name="id" value="a32" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A32" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a34x" />
          <option name="id" value="a34x" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A34 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a35x" />
          <option name="id" value="a35x" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A35 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a35x" />
          <option name="id" value="a35x" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A35 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a35x" />
          <option name="id" value="a35x" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A35 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a36xq" />
          <option name="id" value="a36xq" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A36 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a36xq" />
          <option name="id" value="a36xq" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A36 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a52xq" />
          <option name="id" value="a52xq" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A52 5G" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a54xue" />
          <option name="id" value="a54xue" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A54 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a55xzh" />
          <option name="id" value="a55xzh" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A55 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="a56x" />
          <option name="id" value="a56x" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy A56 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="google" />
          <option name="codename" value="akita" />
          <option name="id" value="akita" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 8a" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="google" />
          <option name="codename" value="akita" />
          <option name="id" value="akita" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 8a" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="motorola" />
          <option name="codename" value="arcfox" />
          <option name="id" value="arcfox" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="razr plus 2024" />
          <option name="screenDensity" value="360" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="1272" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="30" />
          <option name="brand" value="motorola" />
          <option name="codename" value="aruba" />
          <option name="id" value="aruba" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto e20" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="motorola" />
          <option name="codename" value="austin" />
          <option name="id" value="austin" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto g 5G (2022)" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="b0q" />
          <option name="id" value="b0q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S22 Ultra" />
          <option name="screenDensity" value="600" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="3088" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="b0q" />
          <option name="id" value="b0q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S22 Ultra" />
          <option name="screenDensity" value="600" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="3088" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="b0qksx" />
          <option name="id" value="b0qksx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S22 Ultra" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2316" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="b0qxxx" />
          <option name="id" value="b0qxxx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S22 Ultra" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2316" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="b4qsqw" />
          <option name="id" value="b4qsqw" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Z Flip4" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2640" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="b5qsqw" />
          <option name="id" value="b5qsqw" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Z Flip5" />
          <option name="screenDensity" value="340" />
          <option name="screenX" value="748" />
          <option name="screenY" value="720" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="b5qxeea" />
          <option name="id" value="b5qxeea" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Z Flip5" />
          <option name="screenDensity" value="340" />
          <option name="screenX" value="748" />
          <option name="screenY" value="720" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="b6q" />
          <option name="id" value="b6q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Z Flip6" />
          <option name="screenDensity" value="340" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2640" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="b6qksx" />
          <option name="id" value="b6qksx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Z Flip6" />
          <option name="screenDensity" value="340" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2640" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="b6qsqw" />
          <option name="id" value="b6qsqw" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Z Flip6" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2640" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="google" />
          <option name="codename" value="blazer" />
          <option name="default" value="true" />
          <option name="id" value="blazer" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 10 Pro" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2410" />
          <option name="tags">
            <list>
              <option value="dda-default" />
            </list>
          </option>
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="32" />
          <option name="brand" value="google" />
          <option name="codename" value="bluejay" />
          <option name="id" value="bluejay" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 6a" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="c1q" />
          <option name="id" value="c1q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Note20 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="c1qksw" />
          <option name="id" value="c1qksw" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Note20 5G" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="c2q" />
          <option name="id" value="c2q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Note20 Ultra 5G" />
          <option name="screenDensity" value="560" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="3088" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="c2qksw" />
          <option name="id" value="c2qksw" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Note20 Ultra 5G" />
          <option name="screenDensity" value="560" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="3088" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="c2s" />
          <option name="id" value="c2s" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Note20 Ultra 5G" />
          <option name="screenDensity" value="560" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="3088" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="google" />
          <option name="codename" value="caiman" />
          <option name="id" value="caiman" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 9 Pro" />
          <option name="screenDensity" value="360" />
          <option name="screenX" value="960" />
          <option name="screenY" value="2142" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="google" />
          <option name="codename" value="caiman" />
          <option name="id" value="caiman" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 9 Pro" />
          <option name="screenDensity" value="360" />
          <option name="screenX" value="960" />
          <option name="screenY" value="2142" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="motorola" />
          <option name="codename" value="cancun" />
          <option name="id" value="cancun" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto g14" />
          <option name="screenDensity" value="400" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="google" />
          <option name="codename" value="comet" />
          <option name="id" value="comet" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 9 Pro Fold" />
          <option name="screenDensity" value="390" />
          <option name="screenX" value="2076" />
          <option name="screenY" value="2152" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="google" />
          <option name="codename" value="comet" />
          <option name="id" value="comet" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 9 Pro Fold" />
          <option name="screenDensity" value="390" />
          <option name="screenX" value="2076" />
          <option name="screenY" value="2152" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="google" />
          <option name="codename" value="comet" />
          <option name="id" value="comet" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 9 Pro Fold" />
          <option name="screenDensity" value="390" />
          <option name="screenX" value="2076" />
          <option name="screenY" value="2152" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="37" />
          <option name="brand" value="google" />
          <option name="codename" value="cubs" />
          <option name="id" value="cubs" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 11" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2424" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="motorola" />
          <option name="codename" value="cuscoi" />
          <option name="id" value="cuscoi" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto g96 5G" />
          <option name="screenDensity" value="400" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="dm1q" />
          <option name="id" value="dm1q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S23" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="dm1q-SM-S911U" />
          <option name="id" value="dm1q-SM-S911U" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S23" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="dm1qcsx" />
          <option name="id" value="dm1qcsx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S23" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="dm2q" />
          <option name="id" value="dm2q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S23+" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="dm2qksx" />
          <option name="id" value="dm2qksx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S23+" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="dm3q" />
          <option name="id" value="dm3q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S23 Ultra" />
          <option name="screenDensity" value="600" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="3088" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="motorola" />
          <option name="codename" value="dubai" />
          <option name="id" value="dubai" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="edge 30" />
          <option name="screenDensity" value="405" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="e1q" />
          <option name="id" value="e1q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S24" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="e1q" />
          <option name="id" value="e1q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S24" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="e1s" />
          <option name="id" value="e1s" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S24" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="e2q" />
          <option name="id" value="e2q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S24+" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="e2s" />
          <option name="id" value="e2s" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S24+" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="e2sksx" />
          <option name="id" value="e2sksx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S24+" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="e3q" />
          <option name="id" value="e3q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S24 Ultra" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="3120" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="e3q" />
          <option name="id" value="e3q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S24 Ultra" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="3120" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="e3qcsx" />
          <option name="id" value="e3qcsx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S24 Ultra" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="3120" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="e3qksx" />
          <option name="id" value="e3qksx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S24 Ultra" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="3120" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="google" />
          <option name="codename" value="eos" />
          <option name="id" value="eos" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Eos" />
          <option name="screenDensity" value="320" />
          <option name="screenX" value="384" />
          <option name="screenY" value="384" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="google" />
          <option name="codename" value="felix" />
          <option name="id" value="felix" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel Fold" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="2208" />
          <option name="screenY" value="1840" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="google" />
          <option name="codename" value="felix" />
          <option name="id" value="felix" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel Fold" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="2208" />
          <option name="screenY" value="1840" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="google" />
          <option name="codename" value="felix" />
          <option name="id" value="felix" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel Fold" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="2208" />
          <option name="screenY" value="1840" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="google" />
          <option name="codename" value="felix_camera" />
          <option name="id" value="felix_camera" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel Fold (Camera-enabled)" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="2208" />
          <option name="screenY" value="1840" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="motorola" />
          <option name="codename" value="fogona" />
          <option name="id" value="fogona" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto g play - 2024" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="motorola" />
          <option name="codename" value="fogorow" />
          <option name="id" value="fogorow" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto g24" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1612" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="motorola" />
          <option name="codename" value="fogos" />
          <option name="id" value="fogos" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto g34 5G" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="google" />
          <option name="codename" value="frankel" />
          <option name="default" value="true" />
          <option name="id" value="frankel" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 10" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2424" />
          <option name="tags">
            <list>
              <option value="dda-default" />
            </list>
          </option>
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="g0q" />
          <option name="id" value="g0q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S22+" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="g0q" />
          <option name="id" value="g0q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S22+" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="g0qksx" />
          <option name="id" value="g0qksx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S22+" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="motorola" />
          <option name="codename" value="gnevan" />
          <option name="id" value="gnevan" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto g stylus (2023)" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="37" />
          <option name="brand" value="google" />
          <option name="codename" value="grizzly" />
          <option name="id" value="grizzly" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 11 Pro" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2410" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="31" />
          <option name="brand" value="samsung" />
          <option name="codename" value="gta4lwifi" />
          <option name="id" value="gta4lwifi" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Tab A7" />
          <option name="screenDensity" value="240" />
          <option name="screenX" value="1200" />
          <option name="screenY" value="2000" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="gta9pwifi" />
          <option name="id" value="gta9pwifi" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Tab A9+" />
          <option name="screenDensity" value="240" />
          <option name="screenX" value="1200" />
          <option name="screenY" value="1920" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="gts10pwifi" />
          <option name="formFactor" value="Tablet" />
          <option name="id" value="gts10pwifi" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Tab S10+" />
          <option name="screenDensity" value="320" />
          <option name="screenX" value="1752" />
          <option name="screenY" value="2800" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="gts7lwifi" />
          <option name="id" value="gts7lwifi" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Tab S7" />
          <option name="screenDensity" value="340" />
          <option name="screenX" value="1600" />
          <option name="screenY" value="2560" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="gts7xllite" />
          <option name="id" value="gts7xllite" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Tab S7 FE 5G" />
          <option name="screenDensity" value="340" />
          <option name="screenX" value="1600" />
          <option name="screenY" value="2560" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="gts7xlwifi" />
          <option name="id" value="gts7xlwifi" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Tab S7+" />
          <option name="screenDensity" value="340" />
          <option name="screenX" value="1752" />
          <option name="screenY" value="2800" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="gts8uwifi" />
          <option name="formFactor" value="Tablet" />
          <option name="id" value="gts8uwifi" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Tab S8 Ultra" />
          <option name="screenDensity" value="320" />
          <option name="screenX" value="1848" />
          <option name="screenY" value="2960" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="gts8wifi" />
          <option name="formFactor" value="Tablet" />
          <option name="id" value="gts8wifi" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Tab S8" />
          <option name="screenDensity" value="274" />
          <option name="screenX" value="1600" />
          <option name="screenY" value="2560" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="gts9fe" />
          <option name="id" value="gts9fe" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Tab S9 FE 5G" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="2304" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="gts9wifi" />
          <option name="id" value="gts9wifi" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Tab S9" />
          <option name="screenDensity" value="340" />
          <option name="screenX" value="1600" />
          <option name="screenY" value="2560" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="30" />
          <option name="brand" value="motorola" />
          <option name="codename" value="guamna" />
          <option name="id" value="guamna" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto g play (2021)" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="30" />
          <option name="brand" value="motorola" />
          <option name="codename" value="guamp" />
          <option name="id" value="guamp" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto g(9) play" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="google" />
          <option name="codename" value="husky" />
          <option name="id" value="husky" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 8 Pro" />
          <option name="screenDensity" value="390" />
          <option name="screenX" value="1008" />
          <option name="screenY" value="2244" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="google" />
          <option name="codename" value="husky" />
          <option name="id" value="husky" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 8 Pro" />
          <option name="screenDensity" value="390" />
          <option name="screenX" value="1008" />
          <option name="screenY" value="2244" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="30" />
          <option name="brand" value="motorola" />
          <option name="codename" value="java" />
          <option name="id" value="java" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="G20" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="motorola" />
          <option name="codename" value="kansas" />
          <option name="id" value="kansas" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto g - 2025" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1604" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="google" />
          <option name="codename" value="komodo" />
          <option name="id" value="komodo" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 9 Pro XL" />
          <option name="screenDensity" value="360" />
          <option name="screenX" value="1008" />
          <option name="screenY" value="2244" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="google" />
          <option name="codename" value="komodo" />
          <option name="id" value="komodo" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 9 Pro XL" />
          <option name="screenDensity" value="360" />
          <option name="screenX" value="1008" />
          <option name="screenY" value="2244" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="motorola" />
          <option name="codename" value="lamul" />
          <option name="id" value="lamul" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto g05" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1604" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="motorola" />
          <option name="codename" value="lion" />
          <option name="id" value="lion" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto g04" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1612" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="google" />
          <option name="codename" value="lynx" />
          <option name="id" value="lynx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 7a" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="motorola" />
          <option name="codename" value="lyriq" />
          <option name="id" value="lyriq" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="edge 40" />
          <option name="screenDensity" value="400" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="m1q" />
          <option name="id" value="m1q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S26" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="m2q" />
          <option name="id" value="m2q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S26+" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="motorola" />
          <option name="codename" value="malmo" />
          <option name="id" value="malmo" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto g85 5G" />
          <option name="screenDensity" value="400" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="motorola" />
          <option name="codename" value="manaus" />
          <option name="id" value="manaus" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="edge 40 neo" />
          <option name="screenDensity" value="400" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="motorola" />
          <option name="codename" value="maui" />
          <option name="id" value="maui" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto g play - 2023" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="google" />
          <option name="codename" value="mustang" />
          <option name="default" value="true" />
          <option name="id" value="mustang" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 10 Pro XL" />
          <option name="screenDensity" value="390" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2404" />
          <option name="tags">
            <list>
              <option value="dda-default" />
            </list>
          </option>
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="o1q" />
          <option name="id" value="o1q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S21 5G" />
          <option name="screenDensity" value="421" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="o1q" />
          <option name="id" value="o1q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S21 5G" />
          <option name="screenDensity" value="421" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="o1s" />
          <option name="id" value="o1s" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S21 5G" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="31" />
          <option name="brand" value="google" />
          <option name="codename" value="oriole" />
          <option name="id" value="oriole" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 6" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="p3q" />
          <option name="id" value="p3q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S21 Ultra 5G" />
          <option name="screenDensity" value="600" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="3200" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="p3s" />
          <option name="id" value="p3s" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S21 Ultra 5G" />
          <option name="screenDensity" value="600" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="3200" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="pa1qksx" />
          <option name="id" value="pa1qksx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S25" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="pa2q" />
          <option name="id" value="pa2q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S25+" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="pa2qxxx" />
          <option name="id" value="pa2qxxx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S25+" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="pa3q" />
          <option name="default" value="true" />
          <option name="id" value="pa3q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S25 Ultra" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
          <option name="tags">
            <list>
              <option value="dda-default" />
            </list>
          </option>
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="pa3q" />
          <option name="default" value="true" />
          <option name="id" value="pa3q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S25 Ultra" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
          <option name="tags">
            <list>
              <option value="dda-default" />
            </list>
          </option>
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="google" />
          <option name="codename" value="panther" />
          <option name="id" value="panther" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 7" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="motorola" />
          <option name="codename" value="penang" />
          <option name="id" value="penang" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Motorola" />
          <option name="name" value="moto g53 5G" />
          <option name="screenDensity" value="280" />
          <option name="screenX" value="720" />
          <option name="screenY" value="1600" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="psq" />
          <option name="id" value="psq" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S25 Edge" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="3120" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="q2qsqw" />
          <option name="id" value="q2qsqw" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Z Fold3 5G" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="832" />
          <option name="screenY" value="2268" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="q4qksx" />
          <option name="id" value="q4qksx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Z Fold4" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1812" />
          <option name="screenY" value="2176" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="q5q" />
          <option name="id" value="q5q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Z Fold5" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1812" />
          <option name="screenY" value="2176" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="q5qksx" />
          <option name="id" value="q5qksx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Z Fold5" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1812" />
          <option name="screenY" value="2176" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="q6q" />
          <option name="id" value="q6q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Z Fold6" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1856" />
          <option name="screenY" value="2160" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="q6qksx" />
          <option name="id" value="q6qksx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Z Fold6" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1856" />
          <option name="screenY" value="2160" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="q6qsqw" />
          <option name="id" value="q6qsqw" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Z Fold6" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1856" />
          <option name="screenY" value="2160" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="q7mq" />
          <option name="id" value="q7mq" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy Z TriFold" />
          <option name="screenDensity" value="320" />
          <option name="screenX" value="2160" />
          <option name="screenY" value="1584" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="r0q" />
          <option name="id" value="r0q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S22" />
          <option name="screenDensity" value="425" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="r0qcsx" />
          <option name="id" value="r0qcsx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S22" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="r0qksx" />
          <option name="id" value="r0qksx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S22" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="30" />
          <option name="brand" value="google" />
          <option name="codename" value="r11" />
          <option name="formFactor" value="Wear OS" />
          <option name="id" value="r11" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel Watch" />
          <option name="screenDensity" value="320" />
          <option name="screenX" value="384" />
          <option name="screenY" value="384" />
          <option name="type" value="WEAR_OS" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="r11q" />
          <option name="id" value="r11q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S23 FE" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="r11qcs" />
          <option name="id" value="r11qcs" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S23 FE" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="r11s" />
          <option name="id" value="r11s" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S23 FE" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="r8q" />
          <option name="id" value="r8q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S20 FE 5G" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="r8qcsx" />
          <option name="id" value="r8qcsx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S20 FE 5G" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="r8qksx" />
          <option name="id" value="r8qksx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S20 FE 5G" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="r9q" />
          <option name="id" value="r9q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S21 FE 5G" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="r9q-SM-G990U" />
          <option name="id" value="r9q-SM-G990U" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S21 FE 5G" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="samsung" />
          <option name="codename" value="r9q2csx" />
          <option name="id" value="r9q2csx" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S21 FE 5G" />
          <option name="screenDensity" value="480" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="google" />
          <option name="codename" value="rango" />
          <option name="default" value="true" />
          <option name="id" value="rango" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 10 Pro Fold" />
          <option name="screenDensity" value="390" />
          <option name="screenX" value="2076" />
          <option name="screenY" value="2152" />
          <option name="tags">
            <list>
              <option value="dda-default" />
            </list>
          </option>
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="30" />
          <option name="brand" value="google" />
          <option name="codename" value="redfin" />
          <option name="id" value="redfin" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 5" />
          <option name="screenDensity" value="440" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2340" />
          <option name="tags">
            <list>
              <option value="default" />
            </list>
          </option>
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="google" />
          <option name="codename" value="shiba" />
          <option name="id" value="shiba" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 8" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="google" />
          <option name="codename" value="shiba" />
          <option name="id" value="shiba" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 8" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="t2q" />
          <option name="id" value="t2q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S21+ 5G" />
          <option name="screenDensity" value="394" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="samsung" />
          <option name="codename" value="t2q" />
          <option name="id" value="t2q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S21+ 5G" />
          <option name="screenDensity" value="394" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2400" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="google" />
          <option name="codename" value="tangorpro" />
          <option name="formFactor" value="Tablet" />
          <option name="id" value="tangorpro" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel Tablet" />
          <option name="screenDensity" value="320" />
          <option name="screenX" value="1600" />
          <option name="screenY" value="2560" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="google" />
          <option name="codename" value="tangorpro" />
          <option name="formFactor" value="Tablet" />
          <option name="id" value="tangorpro" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel Tablet" />
          <option name="screenDensity" value="320" />
          <option name="screenX" value="1600" />
          <option name="screenY" value="2560" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="google" />
          <option name="codename" value="tegu" />
          <option name="id" value="tegu" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 9a" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2424" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="google" />
          <option name="codename" value="tokay" />
          <option name="id" value="tokay" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 9" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2424" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="35" />
          <option name="brand" value="google" />
          <option name="codename" value="tokay" />
          <option name="id" value="tokay" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 9" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2424" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="36" />
          <option name="brand" value="google" />
          <option name="codename" value="tokay" />
          <option name="id" value="tokay" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 9" />
          <option name="screenDensity" value="420" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2424" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="34" />
          <option name="brand" value="samsung" />
          <option name="codename" value="xcover7" />
          <option name="id" value="xcover7" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy XCover7" />
          <option name="screenDensity" value="450" />
          <option name="screenX" value="1080" />
          <option name="screenY" value="2408" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="y2q" />
          <option name="id" value="y2q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S20+ 5G" />
          <option name="screenDensity" value="600" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="3200" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="37" />
          <option name="brand" value="google" />
          <option name="codename" value="yogi" />
          <option name="id" value="yogi" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Google" />
          <option name="name" value="Pixel 11 Pro Fold" />
          <option name="screenDensity" value="390" />
          <option name="screenX" value="2076" />
          <option name="screenY" value="2152" />
        </PersistentDeviceSelectionData>
        <PersistentDeviceSelectionData>
          <option name="api" value="33" />
          <option name="brand" value="samsung" />
          <option name="codename" value="z3q" />
          <option name="id" value="z3q" />
          <option name="labId" value="google" />
          <option name="manufacturer" value="Samsung" />
          <option name="name" value="Galaxy S20 Ultra 5G" />
          <option name="screenDensity" value="560" />
          <option name="screenX" value="1440" />
          <option name="screenY" value="3200" />
        </PersistentDeviceSelectionData>
      </list>
    </option>
  </component>
</project>